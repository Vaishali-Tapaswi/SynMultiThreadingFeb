import java.util.ArrayList;
import java.util.List;

public class Lab6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable ramrunnable = ()->{
			
			for (int i=0; i<1000000; i++) {
				List<String> list = new ArrayList<>();
				for (int j=0; j<10000; j++) {
					list.add("str"+j);					
				}
				System.out.println("Done with inner loop: "+i);
			}
			System.out.println("Done with outer loop");
		};
		Runnable cpurunnable = ()->{
			
			for (int i=0; i<1000000; i++) {
			
				for (int j=0; j<10000; j++) {
					int k = i*j;					
				}
				System.out.println("Done with inner loop: "+i);
			}
			System.out.println("Done with outer loop");
		};

		
}
}