
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.function.Predicate;
class MyRecursiveTaskLab4 extends RecursiveTask<List<String>>
{
	List<String> list;
	Predicate<String> filter;
	
	public MyRecursiveTaskLab4(List<String> list, Predicate<String> filter) {
		this.list = list;
		this.filter = filter;
	}

	 private List<MyRecursiveTaskLab4> forkthetasks() {
	        List<MyRecursiveTaskLab4> subtasks =     new ArrayList<MyRecursiveTaskLab4 >();

	        MyRecursiveTaskLab4  subtask1 = new MyRecursiveTaskLab4 (list.subList(0, list.size()/2), filter);
	        MyRecursiveTaskLab4  subtask2 = new MyRecursiveTaskLab4 (list.subList( list.size()/2,  list.size()), filter);
	        subtasks.add(subtask1);
	        subtasks.add(subtask2);
	        return subtasks;
	    }

protected List<String> compute() {
		System.out.println("In compute of RecursiveTask, current list size " + list.size()  + " , " + Thread.currentThread().getName());
		 //if work is above threshold, break tasks up into smaller tasks
        if(this.list.size() >=100) {
            System.out.println("Splitting workLoad : " + this.list.size());
    
	        List<MyRecursiveTaskLab4 > subtasks =   forkthetasks();

            for(MyRecursiveTaskLab4  subtask : subtasks){
                subtask.fork();
            }
        
        	List<String> list1 = new ArrayList<String>(); 
          
            for(MyRecursiveTaskLab4  subtask : subtasks) {
               list1.addAll(subtask.join());
            }
            return list1;

        } else {
            System.out.println("Doing workLoad myself: " + this.list);
        	List<String> list1 = new ArrayList<String>(); 
        	
        	for (int i = 0; i< list.size();i++){
        		for(int k =0;k<4000000;k++){
        			String str ="sss"+k;
        		}
    			if (filter.test(list.get(i)))
    					list1.add(list.get(i));
    		}
    		return list1;
        }
	}
}



public class Lab4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Entter a number to continue..");
		scanner.nextInt();
	

		List<String> list = new ArrayList<>();
		for (int i = 0; i< 400;i++){
				list.add("str"+i);
		}
		Predicate<String> pred = (str)->str.length()>5;
		System.out.println("Before Creating Recursive Task");		
		MyRecursiveTaskLab4 task = new MyRecursiveTaskLab4(list, pred);
		System.out.println("Before Creating ForkJoinPool");
		ForkJoinPool forkJoinPool = new ForkJoinPool();
		System.out.println("Before calling Invoke");
		List<String> sortedlist = forkJoinPool.invoke(task);
			System.out.println(sortedlist);
	}

}
