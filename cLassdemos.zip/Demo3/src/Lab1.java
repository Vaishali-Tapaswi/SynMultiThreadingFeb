import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

class Lab1Support implements Runnable{
	private CountDownLatch latch;
	public Lab1Support(CountDownLatch latch) {
		this.latch = latch;
	}
	
	@Override
	public void run() {
		for (int i = 0; i<99999999 ;i++){
			if (i%1000000==0)					System.out.println(Thread.currentThread().getName() +  " " + i);			}
			System.out.println("Current  Thread is finishing its execution " + Thread.currentThread().getName());
		latch.countDown();
		
	}
}
public class Lab1 {
	public static void main(String[] args) throws Exception {
		CountDownLatch latch = new CountDownLatch(3);
		
		Thread t1 = new Thread(new Lab1Support(latch));
		Thread t2 = new Thread(new Lab1Support(latch));
		Thread t3 = new Thread(new Lab1Support(latch));
		t1.start();
		t2.start();
		t3.start();
		latch.await(); 
		System.out.println("Three thread has finished its execution...");
	}

}
