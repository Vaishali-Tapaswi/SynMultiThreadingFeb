import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Phaser;


class Lab5Helper implements Runnable{
	private Phaser phaser;
	
	public Lab5Helper(Phaser phaser) {
		super();
		this.phaser = phaser;
	}

	public void run() {
		try{
		String name = Thread.currentThread().getName();
		System.out.println("Electrification of " + name +"  started....");
		try{ Thread.sleep((int)(Math.random()*1000));}catch(Exception e){}
//		phaser.arriveAndAwaitAdvance();
		phaser.arrive();
		
		System.out.println("Electrification Done, waiting to start Colouring for " + name);
		try{ Thread.sleep((int)(Math.random()*1000));}catch(Exception e){}
		phaser.arriveAndAwaitAdvance();
		
		System.out.println("Colouring Done, waiting for Furniture for " + name);
		try{ Thread.sleep((int)(Math.random()*1000));}catch(Exception e){}
		phaser.arriveAndAwaitAdvance();
		
		System.out.println(name + " is ready....");
		}catch(Exception e){
			System.out.println(e);
		}
	};
}

public class Lab5 {
public static void main(String[] args) {
	//CyclicBarrier barrier = new CyclicBarrier(3);
	Phaser phaser = new Phaser(3);
	Thread t1 = new Thread(new Lab5Helper(phaser));
	t1.setName("Flat1");
	Thread t2 = new Thread(new Lab5Helper(phaser));
	t2.setName("Flat2");
	Thread t3 = new Thread(new Lab5Helper(phaser));
	t3.setName("Flat3");
	t1.start();
	t2.start();
	t3.start();
}
}
