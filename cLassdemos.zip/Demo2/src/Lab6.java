import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Lab6Helper implements Runnable{
	private List<String> list;
	public Lab6Helper(List<String> list){
		this.list = list;
	}
	
	@Override
	public void run() {
		for (int  i=0; i<1000;i++){
				list.add("str"+i);
	}
		System.out.println("Completing "+ Thread.currentThread().getName());
}
}

public class Lab6 {

	public static void main(String[] args) throws Exception {
	//	List list = new ArrayList<>();
		List list = Collections.synchronizedList(new ArrayList<>());
		Lab6Helper[] arr = new Lab6Helper[5];
		ThreadGroup grp = new ThreadGroup("MyGrp");
		for (int  i=0; i<5;i++){
				arr[i] = new Lab6Helper(list);
				Thread t1 = new Thread(grp, arr[i]);
				t1.start();
		}
	
	//	System.out.println("End of Main with all threads " + list.size());
}
}