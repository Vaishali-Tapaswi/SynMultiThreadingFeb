import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Lab1 {
	public static void main(String[] args) {
		System.out.println("Current Time = " + new Date() + " in thread " + Thread.currentThread().getName());
		Runnable r = ()->System.out.println(new Date() + " in thread " + Thread.currentThread().getName());
		ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);
		ses.schedule(r, 5, TimeUnit.SECONDS);
	}
	
}
