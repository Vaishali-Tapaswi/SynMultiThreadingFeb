import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Lab2 {
	public static void main(String[] args) {
		System.out.println("Current Time = " + new Date() + " in thread " + Thread.currentThread().getName());
		Runnable r = ()->{
			System.out.println(new Date() + " in thread " + Thread.currentThread().getName());
			try{Thread.sleep(1500);}catch(Exception e){}
		};
		ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);
	//	ses.schedule(r, 5, TimeUnit.SECONDS);
		ses.scheduleAtFixedRate(r,5, 1, TimeUnit.SECONDS);
	//	ses.scheduleWithFixedDelay(r,5, 5, TimeUnit.SECONDS);
	}
	
}
