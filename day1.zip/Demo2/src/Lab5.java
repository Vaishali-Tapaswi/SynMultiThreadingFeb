import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
class Lab5Helper implements Callable<String>{

	@Override
	public String call() throws Exception {
		System.out.println("in Call of " + Thread.currentThread().getName());
		try{Thread.sleep(5000);}catch(Exception e){}
		return Thread.currentThread().getName();
	}
	
}
public class Lab5 {

	public static void main(String[] args) throws Exception {
		System.out.println("Enter a number to continue..");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
	
		
		Runnable r = ()->{for (int i = 0; i<5;i++){
				System.out.println(Thread.currentThread().getName() +  " " + i);
		}};
	

	//	ExecutorService service =Executors.newFixedThreadPool(2); 
		ExecutorService service =Executors.newCachedThreadPool();
		Future<String> fstring = service.submit(new Lab5Helper());
		for (int i = 0; i<50;i++){
		service.submit(r);
		}
		
		System.out.println("end of main....");
		System.out.println(" now going to wait for data ...");
		System.out.println("Returned = " + fstring.get()); //Blocking
		service.shutdown();
	}

}

