import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

class Lab7Helper extends Thread{
	private final ReentrantLock lock;
	private List<String> list;
	public Lab7Helper(ReentrantLock lock,List<String> list){
		this.lock = lock;
		this.list = list;
	}
	
	@Override
	public void run() {
		for (int  i=0; i<1000;i++){
			lock.lock();
				list.add("str"+i);
				if (i %500 ==0){
					System.out.println("Take Thread dump");
					System.out.println("Lock information, Queue length " + lock.getQueueLength());
					try{Thread.sleep(5000);}catch(Exception e){}
				}
					
			lock.unlock();
	}
		System.out.println("Completing "+ Thread.currentThread().getName());
}
}

public class Lab7 {
	public static final ReentrantLock lock = new ReentrantLock(true);

	public static void main(String[] args) throws Exception {
		
		List list = new ArrayList<>();
		Lab7Helper[] arr = new Lab7Helper[5];
		for (int  i=0; i<5;i++){
				arr[i] = new Lab7Helper(lock, list);
				arr[i].start();
		}
		for (int  i=0; i<5;i++){
			arr[i].join();
		}
	
		System.out.println("End of Main with all threads " + list.size());
}
}