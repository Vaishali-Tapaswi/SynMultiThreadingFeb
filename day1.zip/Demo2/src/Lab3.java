import java.util.ArrayList;
import java.util.List;

class Lab3Helper extends Thread{
	private List<String> list;
	public Lab3Helper(List<String> list){
		this.list = list;
	}
	
	@Override
	public void run() {
		for (int  i=0; i<1000;i++){
			synchronized (list) {
				list.add("str"+i);
			}
				
	}
		System.out.println("Completing "+ Thread.currentThread().getName());
}
}

public class Lab3 {

	public static void main(String[] args) throws Exception {
		List list = new ArrayList<>();
		Lab3Helper[] arr = new Lab3Helper[5];
		for (int  i=0; i<5;i++){
				arr[i] = new Lab3Helper(list);
				arr[i].start();
		}
		for (int  i=0; i<5;i++){
			arr[i].join();
		}
	
		System.out.println("End of Main with all threads " + list.size());
}
}