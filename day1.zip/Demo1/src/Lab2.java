import java.util.Scanner;

class Lab2Support extends Thread{
	@Override
	public void run() {
		for(int i = 0; i < 500;i++){
			System.out.println("Lab2SupportThread " + Thread.currentThread().getName() + "  " + i);
			try{Thread.sleep(100);}catch(Exception e){}
		}
	}
}
public class Lab2 {

	public static void main(String[] args) {
		System.out.println("Enter a number to continue..");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();

		
		
		Lab2Support ls = new Lab2Support();
		ls.start();
		for(int i = 0; i < 500;i++){
			System.out.println("MainThread " + Thread.currentThread().getName() + "  " + i);
			try{Thread.sleep(100);}catch(Exception e){}
		}

	}

}
