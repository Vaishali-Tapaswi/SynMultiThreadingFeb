import java.util.Scanner;

public class Lab1 {

	public static void main(String[] args) {
		System.out.println("Enter a number to continue..");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		System.out.println("Hello from Main Thread");

	}

}
