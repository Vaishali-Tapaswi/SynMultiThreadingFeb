
public class Lab6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable r = ()->{for (int i = 0; i<9999;i++){
			if (i%1000==0)
				System.out.println(Thread.currentThread().getName() +  " " + i);
		}};
		
		Thread t1 =new Thread(r);
		t1.setName("T1");
		t1.setPriority(Thread.MAX_PRIORITY);
	
		Thread t2 =new Thread(r);
		t2.setName("T2");
		
		Thread t3 =new Thread(r);
		t3.setName("T3");
		
		t1.start();
		t2.start();
		t3.start();
		System.out.println("Finished Main");
}
}